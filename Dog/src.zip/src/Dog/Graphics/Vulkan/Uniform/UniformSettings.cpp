/*****************************************************************//**
 * \file   UniformSettings.cpp
 * \author Adi (aditya.prakash@digipen.edu)
 * \date   October 27 2024
 * \Copyright @ 2024 Digipen (USA) Corporation * 
 
 * \brief  Does this file need a header?
 *  *********************************************************************/

#include <PCH/pch.h>
#include "UniformSettings.h"
