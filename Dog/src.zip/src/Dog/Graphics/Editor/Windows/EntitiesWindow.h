#pragma once

#ifndef DOG_SHIP

namespace Dog {

	void UpdateEntitiesWindow();
	class Entity GetSelectedEntity();
	void ResetSelectedEntity();

}

#endif