#pragma once

#ifndef DOG_SHIP

namespace Dog {

	void UpdateInspectorWindow();

}

#endif